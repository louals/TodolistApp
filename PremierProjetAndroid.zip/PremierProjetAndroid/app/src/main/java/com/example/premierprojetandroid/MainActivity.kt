package com.example.premierprojetandroid
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var taskListView: ListView
    private lateinit var taskAdapter: TaskAdapter
    private val taskList = mutableListOf<Task>()


    private val addTaskLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val newTask = result.data?.getParcelableExtra<Task>("NEW_TASK")
            newTask?.let {
                taskList.add(it)
                taskAdapter.notifyDataSetChanged()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        taskListView = findViewById(R.id.listViewTasks)
        val addTaskButton = findViewById<Button>(R.id.buttonAddTask)

        taskAdapter = TaskAdapter(this, taskList)
        taskListView.adapter = taskAdapter


        addTaskButton.setOnClickListener {
            val intent = Intent(this, AddTaskActivity::class.java)
            addTaskLauncher.launch(intent)
        }
    }
}