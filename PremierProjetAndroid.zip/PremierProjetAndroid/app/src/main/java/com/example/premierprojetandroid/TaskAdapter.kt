package com.example.premierprojetandroid

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.view.ViewCompat
import android.widget.ArrayAdapter
import java.text.SimpleDateFormat
import java.util.*

class TaskAdapter(context: Context, tasks: List<Task>) : ArrayAdapter<Task>(context, 0, tasks) {

    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.task_list_item, parent, false)
        }

        val task = getItem(position)
        val taskNameTextView = view!!.findViewById<TextView>(R.id.textViewTaskName)
        val taskDescription = view.findViewById<TextView>(R.id.textViewTaskDescription)
        val priorityTextView = view.findViewById<TextView>(R.id.textViewTaskPriority)
        val deadlineTextView = view.findViewById<TextView>(R.id.textViewTaskDeadline)

        task?.let {
            taskNameTextView.text = it.taskName
            taskDescription.text = it.taskDescription
            priorityTextView.text = it.priority
            deadlineTextView.text = dateFormat.format(it.deadline)
        }

        return view
    }
}