package com.example.premierprojetandroid

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button import android.widget.EditText
import android.widget.Spinner
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.example.premierprojetandroid.R
import com.example.premierprojetandroid.Task
import java.util.*

class AddTaskActivity : AppCompatActivity() {

    private lateinit var taskNameEditText: EditText
    private lateinit var taskNameEditDescription: EditText
    private lateinit var taskPrioritySpinner: Spinner
    private lateinit var taskDeadlineButton: Button
    private lateinit var saveButton: Button

    private var selectedDeadline: Calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_task)

        // Récupération des vues depuis le fichier XML
        taskNameEditText = findViewById(R.id.editTextTaskName)
        taskNameEditDescription = findViewById(R.id.editTextTaskDescription)
        taskPrioritySpinner = findViewById(R.id.spinnerTaskPriority)
        taskDeadlineButton = findViewById(R.id.buttonTaskDeadline)
        saveButton = findViewById(R.id.buttonSave)

        // Initialiser le Spinner avec des options pour la priorité
        val priorities = arrayOf("Haute", "Moyenne", "Basse")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, priorities)
        taskPrioritySpinner.adapter = adapter

        // Lorsque l'utilisateur clique pour choisir une date limite
        taskDeadlineButton.setOnClickListener {
            showDatePickerDialog()
        }

        // Lorsque l'utilisateur clique sur le bouton "Sauvegarder"
        saveButton.setOnClickListener {
            saveTask()
        }
    }

    // Fonction pour afficher le DatePickerDialog pour choisir la date limite
    private fun showDatePickerDialog() {
        val datePickerDialog = DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                selectedDeadline.set(Calendar.YEAR, year)
                selectedDeadline.set(Calendar.MONTH, month)
                selectedDeadline.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                updateDeadlineButtonText()
            },
            selectedDeadline.get(Calendar.YEAR),
            selectedDeadline.get(Calendar.MONTH),
            selectedDeadline.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.show()
    }

    // Fonction pour mettre à jour le texte du bouton "Sélectionner une date limite"
    private fun updateDeadlineButtonText() {
        val day = selectedDeadline.get(Calendar.DAY_OF_MONTH)
        val month = selectedDeadline.get(Calendar.MONTH) + 1 // Les mois commencent à 0
        val year = selectedDeadline.get(Calendar.YEAR)
        taskDeadlineButton.text = "Date limite : $day/$month/$year"
    }

    // Fonction pour sauvegarder la tâche et renvoyer l'intention à l'activité principale
    private fun saveTask() {
        val taskName = taskNameEditText.text.toString()
        val taskDescription = taskNameEditDescription.text.toString()
        val priority = taskPrioritySpinner.selectedItem.toString()
        val deadline = selectedDeadline.time

        if (taskName.isNotEmpty()) {
            val newTask = Task(taskName,taskDescription, priority, deadline)

            val resultIntent = Intent()
            resultIntent.putExtra("NEW_TASK", newTask)
            setResult(RESULT_OK, resultIntent)
            finish()
        } else {
            taskNameEditText.error = "Le nom de la tâche est requis"
        }
    }
}
